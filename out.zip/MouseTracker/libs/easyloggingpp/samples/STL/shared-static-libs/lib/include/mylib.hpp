//#include "easylogging++.h"

class MyLib {
public:
    MyLib();
    MyLib(int, char**);
    ~MyLib();
    void event(int a);
};
